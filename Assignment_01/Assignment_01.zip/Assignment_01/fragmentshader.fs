#version 330

in vec3 fColor;
in float fIncrement;
in float fColumns;
in float fRows;
out vec4 sColor;


void main (void) {
float xCell = floor(fColor.r * fColumns);
float yCell = floor(fColor.g * fRows);

float checker = mod(xCell + yCell, 2.0);

sColor = vec4(checker,checker,checker,1);
}

